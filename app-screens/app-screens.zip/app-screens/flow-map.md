# Sanpo screens: the three flows and the home screen

Device: iPhone 17 Pro simulator, light mode, status bar 9:41, location 35.7020, 139.7450 (Iidabashi/Kagurazaka). Hints turned off so tooltips don't cover buttons.
All screenshots are 1206 x 2622 px. Boxes are [x, y, width, height] in pixels, top-left origin.
**The boxes were estimated by eye from the screenshots, not read from the app's view hierarchy, so expect a few pixels of error.** Anything marked "(not captured: outside this scope)" leads to a screen that wasn't part of the brief.

## Notes for the website demo
- **Narita and Haneda immigration walkthroughs are the same.** Narita page 1 and 2 are pixel-identical to Haneda page 1 and 2. Only the airport options screen differs: Narita has a dated warning card above the buttons (arrival-nrt-01-options.png).
- **Floating buttons.** Many screens have round buttons in the bottom right: a photos button, and on some screens a talk button above it. In pixels: photos [1003, 2148, 142, 142], talk [1003, 2329, 142, 142] on screens that have both; on walkthrough pages the single photos button sits in the lower spot [1003, 2329, 142, 142]. Each screen lists the ones it has.
- **The walk saves itself.** After a route is built, going back shows "continue your walk" on the party-size screen. I cleared it before capturing walk-02b so the two party-size screens match.
- **The station card** (walk-01-station-nudge.png) only appears inside a station and only once per session. Outside a station, "sanpo" goes straight to party size.
- **Route screens** scroll. The list of stops sits under the map; the files capture the top of the page, so the first stops show.
- Immigration page 1 and Narita page 1 list eight steps but the counter says "1 / 10" because the walkthrough also has the intro and the final "that's it." page.
- The first walk captured (medium) was built before the short and long ones; walks are built live from Google, so a re-run on another day gives different places.

## home-01-main.png
Home screen: the sanpo walk button, what's nearby, scenarios, five round buttons, the your-tokyo bar and the settings gear.

- Reached from: App launch.
- Tappable elements:
  - "settings (gear)" [1016, 184, 142, 135] -> (not captured: outside this scope)
  - "sanpo" [303, 1105, 600, 149] -> walk-01-station-nudge.png (when standing in a station), otherwise walk-02-party-size.png
  - "what's nearby" [303, 1300, 600, 149] -> (not captured: outside this scope)
  - "scenarios" [303, 1494, 600, 149] -> (not captured: outside this scope)
  - "before you go (checklist icon)" [177, 2147, 132, 131] -> checklist-01-list.png
  - "airport (airplane icon)" [357, 2147, 132, 131] -> airport-01-picker.png
  - "saved places (star icon)" [537, 2147, 131, 131] -> (not captured: outside this scope)
  - "my routes (route icon)" [717, 2147, 132, 131] -> (not captured: outside this scope)
  - "talk (chat bubbles icon)" [897, 2147, 132, 131] -> translations-01-categories.png
  - "your tokyo progress bar" [303, 2346, 600, 105] -> (not captured: outside this scope)

## checklist-01-list.png
Before you go: the checklist, eleven buttons.

- Reached from: home-01-main.png, tap the checklist icon.
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> home-01-main.png
  - "visit japan web" [303, 399, 600, 149] -> (not captured: outside this scope)
  - "passport" [303, 591, 600, 149] -> (not captured: outside this scope)
  - "suica / pasmo" [303, 784, 600, 149] -> (not captured: outside this scope)
  - "maps" [303, 975, 600, 149] -> (not captured: outside this scope)
  - "translation app" [303, 1168, 600, 149] -> (not captured: outside this scope)
  - "mobile data" [303, 1359, 600, 149] -> (not captured: outside this scope)
  - "yen" [303, 1552, 600, 149] -> (not captured: outside this scope)
  - "hotel address" [303, 1743, 600, 149] -> (not captured: outside this scope)
  - "medicine" [303, 1935, 600, 149] -> (not captured: outside this scope)
  - "plug adapter" [303, 2128, 600, 149] -> (not captured: outside this scope)
  - "luggage" [303, 2319, 600, 149] -> (not captured: outside this scope)

## airport-01-picker.png
Airport picker: Haneda or Narita.

- Reached from: home-01-main.png, tap the airplane icon.
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> home-01-main.png
  - "Haneda · HND" [303, 1262, 600, 149] -> arrival-hnd-01-options.png
  - "Narita · NRT" [303, 1456, 600, 149] -> arrival-nrt-01-options.png
  - "photos button (floating)" [1003, 2149, 142, 142] -> (not captured: outside this scope)
  - "talk button (floating)" [1003, 2329, 142, 142] -> (not captured: outside this scope)

## arrival-hnd-01-options.png
Haneda options: immigration, to my hotel, train taxi or uber?, good to know, somewhere else.

- Reached from: airport-01-picker.png, tap "Haneda · HND".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> airport-01-picker.png
  - "immigration" [303, 969, 600, 149] -> arrival-hnd-02-immigration-01.png
  - "to my hotel" [303, 1164, 600, 149] -> arrival-hnd-03-to-my-hotel-01.png
  - "train, taxi or uber?" [303, 1359, 600, 149] -> (not captured: outside this scope)
  - "good to know" [303, 1553, 600, 149] -> (not captured: outside this scope)
  - "somewhere else" [303, 1749, 600, 149] -> (not captured: outside this scope)
  - "photos button (floating)" [1003, 2149, 142, 142] -> (not captured: outside this scope)
  - "talk button (floating)" [1003, 2329, 142, 142] -> (not captured: outside this scope)

## arrival-hnd-02-immigration-01.png
Immigration walkthrough, page 1 of 10: "arriving in japan" and the list of eight steps.

- Reached from: arrival-hnd-01-options.png, tap "immigration".
- Tappable elements:
  - "close (x)" [1062, 235, 96, 94] -> arrival-hnd-01-options.png
  - "start" [303, 2166, 600, 149] -> arrival-hnd-02-immigration-02.png
  - "photos button (floating)" [1003, 2329, 142, 142] -> (not captured: outside this scope)

## arrival-hnd-02-immigration-02.png
Immigration walkthrough, page 2 of 10.

- Reached from: arrival-hnd-02-immigration-01.png, tap "start".
- Tappable elements:
  - "close (x)" [1062, 235, 96, 94] -> arrival-hnd-01-options.png
  - "next" [303, 2166, 600, 149] -> arrival-hnd-02-immigration-03.png
  - "back" [485, 2352, 236, 109] -> arrival-hnd-02-immigration-01.png

## arrival-hnd-02-immigration-03.png
Immigration walkthrough, page 3 of 10.

- Reached from: arrival-hnd-02-immigration-02.png, tap "next".
- Tappable elements:
  - "close (x)" [1062, 235, 96, 94] -> arrival-hnd-01-options.png
  - "next" [303, 2166, 600, 149] -> arrival-hnd-02-immigration-04.png
  - "back" [485, 2352, 236, 109] -> arrival-hnd-02-immigration-02.png

## arrival-hnd-02-immigration-04.png
Immigration walkthrough, page 4 of 10.

- Reached from: arrival-hnd-02-immigration-03.png, tap "next".
- Tappable elements:
  - "close (x)" [1062, 235, 96, 94] -> arrival-hnd-01-options.png
  - "next" [303, 2166, 600, 149] -> arrival-hnd-02-immigration-05.png
  - "back" [485, 2352, 236, 109] -> arrival-hnd-02-immigration-03.png

## arrival-hnd-02-immigration-05.png
Immigration walkthrough, page 5 of 10.

- Reached from: arrival-hnd-02-immigration-04.png, tap "next".
- Tappable elements:
  - "close (x)" [1062, 235, 96, 94] -> arrival-hnd-01-options.png
  - "next" [303, 2166, 600, 149] -> arrival-hnd-02-immigration-06.png
  - "back" [485, 2352, 236, 109] -> arrival-hnd-02-immigration-04.png

## arrival-hnd-02-immigration-06.png
Immigration walkthrough, page 6 of 10.

- Reached from: arrival-hnd-02-immigration-05.png, tap "next".
- Tappable elements:
  - "close (x)" [1062, 235, 96, 94] -> arrival-hnd-01-options.png
  - "next" [303, 2166, 600, 149] -> arrival-hnd-02-immigration-07.png
  - "back" [485, 2352, 236, 109] -> arrival-hnd-02-immigration-05.png

## arrival-hnd-02-immigration-07.png
Immigration walkthrough, page 7 of 10.

- Reached from: arrival-hnd-02-immigration-06.png, tap "next".
- Tappable elements:
  - "close (x)" [1062, 235, 96, 94] -> arrival-hnd-01-options.png
  - "next" [303, 2166, 600, 149] -> arrival-hnd-02-immigration-08.png
  - "back" [485, 2352, 236, 109] -> arrival-hnd-02-immigration-06.png

## arrival-hnd-02-immigration-08.png
Immigration walkthrough, page 8 of 10.

- Reached from: arrival-hnd-02-immigration-07.png, tap "next".
- Tappable elements:
  - "close (x)" [1062, 235, 96, 94] -> arrival-hnd-01-options.png
  - "next" [303, 2166, 600, 149] -> arrival-hnd-02-immigration-09.png
  - "back" [485, 2352, 236, 109] -> arrival-hnd-02-immigration-07.png

## arrival-hnd-02-immigration-09.png
Immigration walkthrough, page 9 of 10.

- Reached from: arrival-hnd-02-immigration-08.png, tap "next".
- Tappable elements:
  - "close (x)" [1062, 235, 96, 94] -> arrival-hnd-01-options.png
  - "next" [303, 2166, 600, 149] -> arrival-hnd-02-immigration-10.png
  - "back" [485, 2352, 236, 109] -> arrival-hnd-02-immigration-08.png

## arrival-hnd-02-immigration-10.png
Immigration walkthrough, page 10 of 10: "that's it." The final screen.

- Reached from: arrival-hnd-02-immigration-09.png, tap "next".
- Tappable elements:
  - "close (x)" [1062, 235, 96, 94] -> arrival-hnd-01-options.png
  - "done" [303, 2166, 600, 149] -> arrival-hnd-01-options.png (the walkthrough closes)
  - "back" [485, 2352, 236, 109] -> arrival-hnd-02-immigration-09.png
  - "photos button (floating)" [1003, 2329, 142, 142] -> (not captured: outside this scope)

## arrival-hnd-03-to-my-hotel-01.png
"Where are you staying?": eight areas.

- Reached from: arrival-hnd-01-options.png, tap "to my hotel".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> arrival-hnd-01-options.png
  - "Tokyo Station" [121, 1080, 464, 149] -> (not captured: outside this scope)
  - "Ginza" [621, 1080, 464, 149] -> (not captured: outside this scope)
  - "Shinjuku" [121, 1266, 464, 149] -> arrival-hnd-03-to-my-hotel-02-shinjuku.png
  - "Shibuya" [621, 1266, 464, 149] -> (not captured: outside this scope)
  - "Ikebukuro" [121, 1452, 464, 149] -> (not captured: outside this scope)
  - "Ueno" [621, 1452, 464, 149] -> (not captured: outside this scope)
  - "Asakusa" [121, 1639, 464, 149] -> (not captured: outside this scope)
  - "Shinagawa" [621, 1639, 464, 149] -> (not captured: outside this scope)
  - "photos button (floating)" [1003, 2149, 142, 142] -> (not captured: outside this scope)
  - "talk button (floating)" [1003, 2329, 142, 142] -> (not captured: outside this scope)

## arrival-hnd-03-to-my-hotel-02-shinjuku.png
Haneda to Shinjuku: choose train & bus, taxi or uber.

- Reached from: arrival-hnd-03-to-my-hotel-01.png, tap "Shinjuku".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> arrival-hnd-03-to-my-hotel-01.png
  - "train & bus" [303, 1266, 600, 149] -> arrival-hnd-03-to-my-hotel-03-train-bus.png
  - "taxi" [303, 1462, 600, 149] -> arrival-hnd-03-to-my-hotel-04-taxi.png
  - "uber" [303, 1656, 600, 149] -> arrival-hnd-03-to-my-hotel-05-uber.png
  - "photos button (floating)" [1003, 2149, 142, 142] -> (not captured: outside this scope)
  - "talk button (floating)" [1003, 2329, 142, 142] -> (not captured: outside this scope)

## arrival-hnd-03-to-my-hotel-03-train-bus.png
Haneda to Shinjuku, train & bus: recommended Keikyu and JR route, then the airport limousine bus (scrolls).

- Reached from: arrival-hnd-03-to-my-hotel-02-shinjuku.png, tap "train & bus".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> arrival-hnd-03-to-my-hotel-02-shinjuku.png
  - "photos button (floating)" [1003, 2149, 142, 142] -> (not captured: outside this scope)
  - "talk button (floating)" [1003, 2329, 142, 142] -> (not captured: outside this scope)

## arrival-hnd-03-to-my-hotel-04-taxi.png
Haneda to Shinjuku, taxi: typical price, five steps and three phrase cards (scrolls).

- Reached from: arrival-hnd-03-to-my-hotel-02-shinjuku.png, tap "taxi".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> arrival-hnd-03-to-my-hotel-02-shinjuku.png
  - "phrase card list" [49, 1973, 1109, 610] -> enlarged phrase card (not captured: outside this scope)
  - "photos button (floating)" [1003, 2149, 142, 142] -> (not captured: outside this scope)
  - "talk button (floating)" [1003, 2329, 142, 142] -> (not captured: outside this scope)

## arrival-hnd-03-to-my-hotel-05-uber.png
Haneda to Shinjuku, uber.

- Reached from: arrival-hnd-03-to-my-hotel-02-shinjuku.png, tap "uber".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> arrival-hnd-03-to-my-hotel-02-shinjuku.png
  - "photos button (floating)" [1003, 2149, 142, 142] -> (not captured: outside this scope)
  - "talk button (floating)" [1003, 2329, 142, 142] -> (not captured: outside this scope)

## arrival-nrt-01-options.png
Narita options: the same five buttons as Haneda, with a dated warning card above them about train works.

- Reached from: airport-01-picker.png, tap "Narita · NRT".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> airport-01-picker.png
  - "warning card (train works notice)" [59, 712, 1088, 444] -> none
  - "immigration" [303, 1226, 600, 149] -> arrival-nrt-02-immigration-01.png
  - "to my hotel" [303, 1420, 600, 149] -> (not captured: outside this scope)
  - "train, taxi or uber?" [303, 1615, 600, 149] -> (not captured: outside this scope)
  - "good to know" [303, 1810, 600, 149] -> (not captured: outside this scope)
  - "somewhere else" [303, 2004, 600, 149] -> (not captured: outside this scope)
  - "photos button (floating)" [1003, 2149, 142, 142] -> (not captured: outside this scope)
  - "talk button (floating)" [1003, 2329, 142, 142] -> (not captured: outside this scope)

## arrival-nrt-02-immigration-01.png
Narita immigration, page 1 of 10. Pixel-identical to the Haneda page 1.

- Reached from: arrival-nrt-01-options.png, tap "immigration".
- Tappable elements:
  - "close (x)" [1062, 235, 96, 94] -> arrival-nrt-01-options.png
  - "start" [303, 2166, 600, 149] -> arrival-nrt-02-immigration-02.png
  - "photos button (floating)" [1003, 2329, 142, 142] -> (not captured: outside this scope)

## arrival-nrt-02-immigration-02.png
Narita immigration, page 2 of 10 (step 1, follow the signs). Pixel-identical to the Haneda page 2.

- Reached from: arrival-nrt-02-immigration-01.png, tap "start".
- Tappable elements:
  - "close (x)" [1062, 235, 96, 94] -> arrival-nrt-01-options.png
  - "next" [303, 2166, 600, 149] -> page 3 (not captured: outside this scope)
  - "back" [485, 2352, 236, 109] -> arrival-nrt-02-immigration-01.png
  - "photos button (floating)" [1003, 2329, 142, 142] -> (not captured: outside this scope)

## walk-01-station-nudge.png
A card that appears when the person is standing in a station: suggests what's nearby, or sanpo anyway. Shown over the home screen.

- Reached from: home-01-main.png, tap "sanpo" (the first time in a session, inside a station).
- Tappable elements:
  - "what's nearby" [303, 1473, 600, 149] -> (not captured: outside this scope)
  - "sanpo anyway" [391, 1665, 426, 121] -> walk-02-party-size.png

## walk-02-party-size.png
Party size: 1 person (一人 · hitori), the sanpo button and "sanpo to a map link".

- Reached from: walk-01-station-nudge.png, tap "sanpo anyway".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> home-01-main.png
  - "minus" [324, 1199, 66, 66] -> same screen, goes down to 1
  - "plus" [815, 1199, 66, 66] -> walk-02b-party-size-two.png
  - "sanpo" [303, 1342, 600, 149] -> walk-03-hunger.png
  - "sanpo to a map link" [295, 1551, 616, 131] -> (not captured: outside this scope)

## walk-02b-party-size-two.png
Party size after tapping + once: 2 people (二人 · futari).

- Reached from: walk-02-party-size.png, tap +.
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> home-01-main.png
  - "minus" [324, 1199, 66, 66] -> walk-02-party-size.png (1 person)
  - "plus" [815, 1199, 66, 66] -> same screen, 3 people
  - "sanpo" [303, 1342, 600, 149] -> walk-03-hunger.png
  - "sanpo to a map link" [295, 1551, 616, 131] -> (not captured: outside this scope)

## walk-03-hunger.png
How hungry: lunch, peckish, dinner, not hungry, show all.

- Reached from: walk-02-party-size.png, tap "sanpo".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> walk-02-party-size.png
  - "lunch" [303, 1021, 600, 149] -> walk-04-preferences.png
  - "peckish" [303, 1213, 600, 149] -> (not captured: outside this scope)
  - "dinner" [303, 1405, 600, 149] -> (not captured: outside this scope)
  - "not hungry" [303, 1597, 600, 149] -> (not captured: outside this scope)
  - "show all" [505, 1802, 197, 39] -> (not captured: outside this scope)

## walk-04-preferences.png
Walk preferences: shrines & temples, museums and shopping on; cards & games, figures & models and anime goods crossed out by default.

- Reached from: walk-03-hunger.png, tap "lunch".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> walk-03-hunger.png
  - "shrines & temples" [303, 738, 600, 149] -> same screen (toggles)
  - "museums" [303, 931, 600, 149] -> same screen (toggles)
  - "shopping" [303, 1122, 600, 149] -> same screen (toggles)
  - "cards & games" [303, 1315, 600, 149] -> same screen (toggles)
  - "figures & models" [303, 1506, 600, 149] -> same screen (toggles)
  - "anime goods" [303, 1699, 600, 149] -> same screen (toggles)
  - "show all" [505, 1894, 197, 39] -> same screen, shows every option
  - "sanpo" [303, 2058, 600, 165] -> walk-05-route-top.png

## walk-05-route-top.png
Medium walk result: five stops, 1.8 km, with the map and the first stops (scrolls).

- Reached from: walk-04-preferences.png, tap "sanpo" (medium is the default).
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> home-01-main.png (walk saved as "continue your walk")
  - "keep screen on (sun icon)" [1025, 186, 132, 132] -> same screen (toggles)
  - "short" [47, 396, 357, 115] -> walk-09-route-short.png
  - "medium" [425, 396, 358, 115] -> walk-05-route-top.png
  - "long" [802, 396, 358, 115] -> walk-10-route-long.png
  - "include chains" [47, 541, 1113, 113] -> same screen, builds the walk again
  - "step through" [81, 839, 404, 100] -> walk-06-step-through-01.png
  - "expand map (arrows)" [1022, 843, 102, 94] -> full-screen map (not captured: outside this scope)
  - "back to my location (arrow)" [1003, 1566, 131, 131] -> same screen
  - "stop 1 swap" [805, 1981, 94, 94] -> same screen (replaces stop 1)
  - "stop 1 remove (x)" [919, 1981, 94, 94] -> same screen (removes stop 1)
  - "stop 1 reorder (lines)" [1033, 1981, 94, 94] -> same screen (reorder mode)
  - "stop 1 card" [173, 1914, 986, 223] -> place page (not captured: outside this scope)

## walk-09-route-short.png
Short walk result: three stops, 790 m.

- Reached from: walk-05-route-top.png, tap "short".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> home-01-main.png (walk saved as "continue your walk")
  - "keep screen on (sun icon)" [1025, 186, 132, 132] -> same screen (toggles)
  - "short" [47, 396, 357, 115] -> walk-09-route-short.png
  - "medium" [425, 396, 358, 115] -> walk-05-route-top.png
  - "long" [802, 396, 358, 115] -> walk-10-route-long.png
  - "include chains" [47, 541, 1113, 113] -> same screen, builds the walk again
  - "step through" [81, 839, 404, 100] -> (step through works as on the medium walk)
  - "expand map (arrows)" [1022, 843, 102, 94] -> full-screen map (not captured: outside this scope)
  - "back to my location (arrow)" [1003, 1566, 131, 131] -> same screen
  - "stop 1 swap" [805, 1981, 94, 94] -> same screen (replaces stop 1)
  - "stop 1 remove (x)" [919, 1981, 94, 94] -> same screen (removes stop 1)
  - "stop 1 reorder (lines)" [1033, 1981, 94, 94] -> same screen (reorder mode)
  - "stop 1 card" [173, 1914, 986, 223] -> place page (not captured: outside this scope)

## walk-10-route-long.png
Long walk result: seven stops, 1.7 km.

- Reached from: walk-05-route-top.png, tap "long".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> home-01-main.png (walk saved as "continue your walk")
  - "keep screen on (sun icon)" [1025, 186, 132, 132] -> same screen (toggles)
  - "short" [47, 396, 357, 115] -> walk-09-route-short.png
  - "medium" [425, 396, 358, 115] -> walk-05-route-top.png
  - "long" [802, 396, 358, 115] -> walk-10-route-long.png
  - "include chains" [47, 541, 1113, 113] -> same screen, builds the walk again
  - "step through" [81, 839, 404, 100] -> (step through works as on the medium walk)
  - "expand map (arrows)" [1022, 843, 102, 94] -> full-screen map (not captured: outside this scope)
  - "back to my location (arrow)" [1003, 1566, 131, 131] -> same screen
  - "stop 1 swap" [805, 1981, 94, 94] -> same screen (replaces stop 1)
  - "stop 1 remove (x)" [919, 1981, 94, 94] -> same screen (removes stop 1)
  - "stop 1 reorder (lines)" [1033, 1981, 94, 94] -> same screen (reorder mode)
  - "stop 1 card" [173, 1914, 986, 223] -> place page (not captured: outside this scope)

## walk-06-step-through-01.png
Step through, started: the map controls change to previous, "whole walk" and next; the page scrolls so the map is at the top.

- Reached from: walk-05-route-top.png, tap "step through".
- Tappable elements:
  - "previous stop (arrow)" [81, 381, 102, 102] -> walk-05-route-top.png (whole walk)
  - "whole walk" [207, 381, 315, 102] -> walk-05-route-top.png (the whole walk)
  - "next stop (arrow)" [545, 381, 102, 102] -> walk-07-step-through-02-stop1.png
  - "expand map (arrows)" [1022, 381, 102, 102] -> full-screen map (not captured: outside this scope)

## walk-07-step-through-02-stop1.png
Step through, the walk to stop 1 (map zoomed to the first leg).

- Reached from: walk-06-step-through-01.png, tap the next arrow.
- Tappable elements:
  - "previous stop (arrow)" [81, 381, 102, 102] -> walk-06-step-through-01.png
  - "whole walk" [207, 381, 315, 102] -> walk-05-route-top.png (the whole walk)
  - "next stop (arrow)" [545, 381, 102, 102] -> walk-08-step-through-03-stop2.png
  - "expand map (arrows)" [1022, 381, 102, 102] -> full-screen map (not captured: outside this scope)

## walk-08-step-through-03-stop2.png
Step through, the walk to stop 2.

- Reached from: walk-07-step-through-02-stop1.png, tap the next arrow.
- Tappable elements:
  - "previous stop (arrow)" [81, 381, 102, 102] -> walk-07-step-through-02-stop1.png
  - "whole walk" [207, 381, 315, 102] -> walk-05-route-top.png (the whole walk)
  - "next stop (arrow)" [545, 381, 102, 102] -> the walk to stop 3 (not captured: outside this scope)
  - "expand map (arrows)" [1022, 381, 102, 102] -> full-screen map (not captured: outside this scope)

## translations-01-categories.png
Talk: nineteen conversation categories, each with its Japanese name.

- Reached from: home-01-main.png, tap the chat bubbles icon.
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> home-01-main.png
  - "trains" [60, 372, 524, 180] -> translations-trains-01-start.png
  - "bus" [621, 372, 524, 180] -> (not captured: outside this scope)
  - "taxi" [60, 589, 524, 180] -> (not captured: outside this scope)
  - "help" [621, 589, 524, 180] -> (not captured: outside this scope)
  - "restaurant" [60, 804, 524, 180] -> (not captured: outside this scope)
  - "ramen shop" [621, 804, 524, 180] -> (not captured: outside this scope)
  - "sushi" [60, 1020, 524, 180] -> (not captured: outside this scope)
  - "at the register" [621, 1020, 524, 180] -> (not captured: outside this scope)
  - "drinks" [60, 1236, 524, 180] -> (not captured: outside this scope)
  - "everyday" [621, 1236, 524, 180] -> translations-everyday-01-start.png
  - "hotel" [60, 1452, 524, 180] -> (not captured: outside this scope)
  - "pharmacy" [621, 1452, 524, 180] -> (not captured: outside this scope)
  - "shopping" [60, 1667, 524, 180] -> (not captured: outside this scope)
  - "atm" [621, 1667, 524, 180] -> (not captured: outside this scope)
  - "coin lockers" [60, 1884, 524, 180] -> (not captured: outside this scope)
  - "bath" [621, 1884, 524, 180] -> (not captured: outside this scope)
  - "laundromat" [60, 2100, 524, 180] -> (not captured: outside this scope)
  - "shrine & temple" [621, 2100, 524, 180] -> (not captured: outside this scope)
  - "museum" [60, 2316, 524, 180] -> (not captured: outside this scope)

## translations-trains-01-start.png
Trains conversation, start: the upside-down card for the staff, "Please choose something to say", and six phrase buttons plus more.

- Reached from: translations-01-categories.png, tap "trains".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> translations-01-categories.png
  - "The ticket gate closed on me" [42, 1660, 545, 146] -> (not captured: outside this scope)
  - "How do I use the fare adjustment machine?" [619, 1660, 545, 146] -> (not captured: outside this scope)
  - "Which platform for...? (needs a place)" [42, 1835, 545, 146] -> translations-trains-03-station-picker.png
  - "Which exit is closest to...?" [619, 1835, 545, 146] -> (not captured: outside this scope)
  - "Does this train go to...?" [42, 2011, 545, 146] -> (not captured: outside this scope)
  - "How do I get to...?" [619, 2011, 545, 146] -> (not captured: outside this scope)
  - "Which line goes to...?" [42, 2187, 545, 146] -> (not captured: outside this scope)
  - "more" [619, 2197, 545, 125] -> translations-trains-02-more.png
  - "photos button" [60, 2353, 143, 142] -> (not captured: outside this scope)
  - "restart" [1003, 2353, 142, 142] -> same conversation, starts over

## translations-trains-02-more.png
Trains conversation, the next page of phrases (after "more").

- Reached from: translations-trains-01-start.png, tap "more".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> translations-01-categories.png
  - "How many stops to...? (needs a place)" [42, 1753, 545, 166] -> a station picker like translations-trains-03-station-picker.png
  - "Do I need to transfer?" [619, 1753, 545, 166] -> translations-trains-04-after-tap.png (a phrase that needs no place; the captured example is "How many stops to here?" after choosing a place)
  - "Where can I buy a ticket?" [42, 1951, 545, 166] -> (not captured: outside this scope)
  - "I left something on the train" [619, 1951, 545, 166] -> (not captured: outside this scope)
  - "more" [42, 2147, 548, 147] -> (not captured: outside this scope)
  - "photos button" [60, 2353, 143, 142] -> (not captured: outside this scope)
  - "restart" [1003, 2353, 142, 142] -> same conversation, starts over

## translations-trains-03-station-picker.png
"Where to?" sheet for phrases that need a place: search, paste, A-Z chips and popular stations.

- Reached from: translations-trains-02-more.png, tap "How many stops to...?".
- Tappable elements:
  - "done" [946, 186, 211, 131] -> translations-trains-02-more.png
  - "station search field" [49, 396, 1109, 138] -> (not captured: outside this scope)
  - "Paste" [472, 575, 262, 104] -> (not captured: outside this scope)
  - "station: Tokyo (東京駅)" [49, 924, 543, 149] -> translations-trains-04-after-tap.png (any station gives the same screen)
  - "station: Shinjuku (新宿駅)" [615, 924, 543, 149] -> translations-trains-04-after-tap.png
  - "use a screenshot instead" [49, 2328, 1109, 144] -> (not captured: outside this scope)

## translations-trains-04-after-tap.png
Trains, after tapping a phrase: the big upside-down card for the staff, six reply buttons for them (also upside-down), and "You said ... please wait" for the visitor.

- Reached from: translations-trains-03-station-picker.png, choose a station (the phrase was "How many stops to...?").
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> translations-01-categories.png
  - "staff reply buttons (six, upside-down)" [42, 389, 1122, 565] -> the conversation continues (not captured: outside this scope)
  - "staff's big card (upside-down)" [42, 983, 1122, 315] -> none
  - "choose a place" [363, 2365, 481, 117] -> translations-trains-03-station-picker.png
  - "photos button" [60, 2353, 143, 142] -> (not captured: outside this scope)
  - "restart" [1003, 2353, 142, 142] -> same conversation, starts over

## translations-everyday-01-start.png
Everyday conversation, start: seven phrase buttons.

- Reached from: translations-01-categories.png, tap "everyday".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> translations-01-categories.png
  - "Where is the bathroom?" [42, 1660, 545, 146] -> (not captured: outside this scope)
  - "Where is the station?" [619, 1660, 545, 146] -> (not captured: outside this scope)
  - "Where is...? (needs a place)" [42, 1835, 545, 146] -> (not captured: outside this scope)
  - "Do you speak English?" [619, 1835, 545, 146] -> (not captured: outside this scope)
  - "Check, please" [42, 2011, 545, 146] -> translations-everyday-02-after-tap.png
  - "How much is this?" [619, 2011, 545, 146] -> (not captured: outside this scope)
  - "Could you take our photo?" [42, 2187, 545, 146] -> (not captured: outside this scope)
  - "photos button" [60, 2353, 143, 142] -> (not captured: outside this scope)
  - "restart" [1003, 2353, 142, 142] -> same conversation, starts over

## translations-everyday-02-after-tap.png
Everyday, after tapping "Check, please": the staff's big upside-down card (お会計をお願いします), three staff reply buttons, and "You said: Check, please ... please wait".

- Reached from: translations-everyday-01-start.png, tap "Check, please".
- Tappable elements:
  - "back chevron" [49, 186, 131, 131] -> translations-01-categories.png
  - "staff reply buttons (three, upside-down)" [42, 389, 1122, 565] -> the conversation continues (not captured: outside this scope)
  - "staff's big card (upside-down)" [42, 983, 1122, 315] -> none
  - "photos button" [60, 2353, 143, 142] -> (not captured: outside this scope)
  - "restart" [1003, 2353, 142, 142] -> same conversation, starts over
